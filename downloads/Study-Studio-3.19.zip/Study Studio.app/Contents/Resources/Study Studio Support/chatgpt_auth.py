"""Local, per-Mac ChatGPT OAuth session for Study Studio."""
import base64, hashlib, hmac, json, os, secrets, subprocess, tempfile, threading, time, urllib.parse, urllib.request, uuid
from pathlib import Path

AUTH='https://auth.openai.com'
RESOURCE='https://api.openai.com/v1'
SCOPES='openid profile email offline_access resource.invoke chatgpt.tokens.use.direct'
SERVICE='Study Studio ChatGPT Credentials'
ACCOUNT='local-user'
_pending={}
_guard=threading.RLock()

def _b64(data): return base64.urlsafe_b64encode(data).rstrip(b'=').decode()
def _unb64(data): return base64.urlsafe_b64decode(data+'='*(-len(data)%4))
def _request(url, data=None):
    headers={'Accept':'application/json'}
    if data is not None: headers['Content-Type']='application/x-www-form-urlencoded'
    req=urllib.request.Request(url, data=urllib.parse.urlencode(data).encode() if data is not None else None, headers=headers)
    with urllib.request.urlopen(req, timeout=20) as r:
        body=r.read()
        return json.loads(body) if body else {}
def _keychain(args): return subprocess.run(['/usr/bin/security',*args],capture_output=True,text=True,timeout=10)
def read():
    r=_keychain(['find-generic-password','-a',ACCOUNT,'-s',SERVICE,'-w'])
    try: return json.loads(r.stdout) if r.returncode==0 else {}
    except ValueError: return {}
def save(record):
    r=_keychain(['add-generic-password','-U','-a',ACCOUNT,'-s',SERVICE,'-w',json.dumps(record,separators=(',',':'))])
    if r.returncode: raise ValueError('Could not save ChatGPT sign-in to macOS Keychain.')
def clear(): _keychain(['delete-generic-password','-a',ACCOUNT,'-s',SERVICE])
def status():
    rec=read()
    signed_in=bool(rec.get('refresh_token'))
    plan_available=signed_in and 'chatgpt.tokens.use.direct' in rec.get('scopes',[])
    return {'connected':signed_in, 'planAvailable':plan_available, 'email':rec.get('email',''), 'mode':'chatgpt' if signed_in else 'none', 'error':rec.get('error','')}
def begin(port):
    with _guard:
        old=read(); state=secrets.token_urlsafe(32); nonce=secrets.token_urlsafe(32); verifier=secrets.token_urlsafe(64)
        host_id=old.get('ext_agent_host_id') or 'urn:uuid:'+str(uuid.uuid4())
        client_id=old.get('client_id') or 'dynamic_agent_client'
        redirect=f'http://127.0.0.1:{port}/auth/callback'
        _pending.clear(); _pending.update(state=state,nonce=nonce,verifier=verifier,client_id=client_id,host_id=host_id,redirect=redirect,started=time.time())
        params={'client_id':client_id,'ext_agent_host_id':host_id,'response_type':'code','redirect_uri':redirect,'scope':SCOPES,'resource':RESOURCE,'state':state,'nonce':nonce,'code_challenge_method':'S256','code_challenge':_b64(hashlib.sha256(verifier.encode()).digest())}
        if client_id=='dynamic_agent_client': params['agent_name_hint']='Study Studio'
        elif old.get('id_token'): params['id_token_hint']=old['id_token']
        return AUTH+'/api/accounts/authorize?'+urllib.parse.urlencode(params)
def _derint(raw):
    raw=raw.lstrip(b'\0') or b'\0'
    if raw[0]&128: raw=b'\0'+raw
    return b'\x02'+_length(len(raw))+raw
def _length(n):
    if n<128:return bytes([n])
    b=n.to_bytes((n.bit_length()+7)//8,'big');return bytes([128+len(b)])+b
def _rsa_pem(jwk):
    seq=_derint(_unb64(jwk['n']))+_derint(_unb64(jwk['e']))
    rsa=b'\x30'+_length(len(seq))+seq
    alg=bytes.fromhex('300d06092a864886f70d0101010500')
    bits=b'\x03'+_length(len(rsa)+1)+b'\x00'+rsa
    der=b'\x30'+_length(len(alg)+len(bits))+alg+bits
    return b'-----BEGIN PUBLIC KEY-----\n'+base64.encodebytes(der)+b'-----END PUBLIC KEY-----\n'
def _verify_id_token(token,client_id,nonce):
    parts=token.split('.')
    if len(parts)!=3:raise ValueError('Invalid identity token.')
    head=json.loads(_unb64(parts[0])); claims=json.loads(_unb64(parts[1]))
    if head.get('alg')!='RS256':raise ValueError('Unexpected identity signature algorithm.')
    jwks=_request(AUTH+'/.well-known/jwks.json')
    key=next((x for x in jwks['keys'] if x.get('kid')==head.get('kid') and x.get('kty')=='RSA'),None)
    if not key:raise ValueError('OpenAI identity signing key unavailable.')
    with tempfile.TemporaryDirectory() as folder:
        pub=Path(folder)/'public.pem';sig=Path(folder)/'signature';msg=Path(folder)/'message'
        pub.write_bytes(_rsa_pem(key));sig.write_bytes(_unb64(parts[2]));msg.write_bytes((parts[0]+'.'+parts[1]).encode())
        result=subprocess.run(['/usr/bin/openssl','dgst','-sha256','-verify',str(pub),'-signature',str(sig),str(msg)],capture_output=True,timeout=10)
        if result.returncode:raise ValueError('OpenAI identity signature failed verification.')
    if claims.get('iss')!=AUTH: raise ValueError('OpenAI identity issuer did not match. Sign in again.')
    audience=claims.get('aud')
    if client_id not in ([audience] if isinstance(audience,str) else audience if isinstance(audience,list) else []):
        raise ValueError('OpenAI identity audience did not match this app. Sign in again.')
    if claims.get('nonce')!=nonce: raise ValueError('OpenAI sign-in nonce did not match. Sign in again.')
    if not isinstance(claims.get('exp'),(int,float)) or claims['exp']<time.time()-5:
        raise ValueError('OpenAI identity token expired. Sign in again.')
    if not isinstance(claims.get('sub'),str) or not claims['sub']:
        raise ValueError('OpenAI identity token had no account ID. Sign in again.')
    return claims

def callback(query):
    with _guard:
        txn=dict(_pending);_pending.clear()
        if not txn or time.time()-txn['started']>600:raise ValueError('Sign-in timed out. Try again.')
        if not hmac.compare_digest(query.get('state',[''])[0],txn['state']):raise ValueError('Sign-in state did not match.')
        if query.get('error'):raise ValueError('ChatGPT sign-in was canceled or declined.')
        code=query.get('code',[''])[0];issued=query.get('client_id',[txn['client_id']])[0]
        if not code or issued=='dynamic_agent_client':raise ValueError('ChatGPT did not finish registration.')
        if txn['client_id']!='dynamic_agent_client' and issued!=txn['client_id']:raise ValueError('Unexpected ChatGPT client registration.')
        token=_request(AUTH+'/api/accounts/oauth/token',{'grant_type':'authorization_code','client_id':issued,'code':code,'code_verifier':txn['verifier'],'redirect_uri':txn['redirect'],'resource':RESOURCE})
        claims=_verify_id_token(token['id_token'],issued,txn['nonce'])
        prior=read()
        if prior.get('client_id')==issued and prior.get('subject') and prior['subject']!=claims['sub']:raise ValueError('Different ChatGPT account selected. Sign out before changing accounts.')
        scopes=token.get('scope','').split()
        rec={'client_id':issued,'ext_agent_host_id':txn['host_id'],'issuer':AUTH,'subject':claims['sub'],'email':claims.get('email',''),'id_token':token['id_token'],'access_token':token['access_token'],'refresh_token':token['refresh_token'],'scopes':scopes,'expires_at':time.time()+int(token.get('expires_in',3600))}
        save(rec);return rec

def access_token():
    with _guard:
        rec=read()
        if not rec.get('refresh_token'):raise ValueError('Continue with ChatGPT first.')
        if rec.get('expires_at',0)<time.time()+120:
            token=_request(AUTH+'/api/accounts/oauth/token',{'grant_type':'refresh_token','client_id':rec['client_id'],'refresh_token':rec['refresh_token'],'resource':RESOURCE})
            rec.update(access_token=token['access_token'],refresh_token=token.get('refresh_token',rec['refresh_token']),expires_at=time.time()+int(token.get('expires_in',3600)),scopes=token.get('scope',' '.join(rec['scopes'])).split())
            save(rec)
        if 'chatgpt.tokens.use.direct' not in rec['scopes']:raise ValueError('ChatGPT plan access is unavailable. Sign in again.')
        return rec['access_token']

def sign_out():
    rec=read()
    revoked=True
    if rec.get('refresh_token'):
        try:_request(AUTH+'/api/accounts/oauth/revoke',{'token':rec['refresh_token'],'token_type_hint':'refresh_token','client_id':rec['client_id']})
        except Exception:revoked=False
    clear()
    return {'connected':False,'revoked':revoked}
